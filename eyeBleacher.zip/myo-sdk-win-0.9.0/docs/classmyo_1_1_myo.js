var classmyo_1_1_myo =
[
    [ "StreamEmgType", "classmyo_1_1_myo.html#aa339313b6386bb2cb3e4cbe69ea10a4b", [
      [ "streamEmgDisabled", "classmyo_1_1_myo.html#aa339313b6386bb2cb3e4cbe69ea10a4baaf785c7ec248048499f865d1c7e749a5", null ],
      [ "streamEmgEnabled", "classmyo_1_1_myo.html#aa339313b6386bb2cb3e4cbe69ea10a4ba596f412909010ee08e8f5661c8553f12", null ]
    ] ],
    [ "UnlockType", "classmyo_1_1_myo.html#a46497cc40a6ea496f1022643adfe71cc", [
      [ "unlockTimed", "classmyo_1_1_myo.html#a46497cc40a6ea496f1022643adfe71cca397cf13a5bf3f42d4b179ac5d2d68430", null ],
      [ "unlockHold", "classmyo_1_1_myo.html#a46497cc40a6ea496f1022643adfe71ccaa6d48131f43d37226aa1922610e350f7", null ]
    ] ],
    [ "VibrationType", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271", [
      [ "vibrationShort", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271a8d7b7af0de494b200a3f94332e6da3f7", null ],
      [ "vibrationMedium", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271ab06d9e4bccbc98add36e397599835833", null ],
      [ "vibrationLong", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271ac5ab3818975f6f0aa3234f614941b805", null ]
    ] ],
    [ "lock", "classmyo_1_1_myo.html#a4086dc1ed5737b600677c373e657a377", null ],
    [ "notifyUserAction", "classmyo_1_1_myo.html#ac54c392d495c2824149c0ff69cd63633", null ],
    [ "requestBatteryLevel", "classmyo_1_1_myo.html#a7fb0194bf3c2f5b5bcd8064ac26832b1", null ],
    [ "requestRssi", "classmyo_1_1_myo.html#a38477309f70709e2bf1d3d1a82d30e00", null ],
    [ "setStreamEmg", "classmyo_1_1_myo.html#a1aa96dbe82263c277dcfa6814ea22ab9", null ],
    [ "unlock", "classmyo_1_1_myo.html#abc7c0f4efe0914ea4c006a7d2114fb79", null ],
    [ "vibrate", "classmyo_1_1_myo.html#a5364a3d446c8d60fdc381b0bb2cb6c92", null ],
    [ "Hub", "classmyo_1_1_myo.html#aea14f5495b4697c28ed665a9054acf5e", null ]
];