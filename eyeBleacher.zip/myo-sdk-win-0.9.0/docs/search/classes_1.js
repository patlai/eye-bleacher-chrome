var searchData=
[
  ['firmwareversion',['FirmwareVersion',['../structmyo_1_1_firmware_version.html',1,'myo']]]
];
