var searchData=
[
  ['y',['y',['../classmyo_1_1_quaternion.html#a7ed60595d23102df65c3358a8168247b',1,'myo::Quaternion::y()'],['../classmyo_1_1_vector3.html#a4ec140546c075756199a9fca7e9fd849',1,'myo::Vector3::y()']]]
];
