var searchData=
[
  ['setlockingpolicy',['setLockingPolicy',['../classmyo_1_1_hub.html#a250ecf8e81d9e86852d29651abc1c70f',1,'myo::Hub']]],
  ['setstreamemg',['setStreamEmg',['../classmyo_1_1_myo.html#a1aa96dbe82263c277dcfa6814ea22ab9',1,'myo::Myo']]]
];
